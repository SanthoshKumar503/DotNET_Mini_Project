﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace Win_Banking_Application_ADO
{
    class BankingDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);
        public int AddCustomers(Customers c)
        {
            if (c == null)
            {
                throw new Exception("Invalid Add Customer");
            }
            SqlCommand com_addCust = new SqlCommand("p_addCustomer", con);
            com_addCust.CommandType = CommandType.StoredProcedure;
            com_addCust.Parameters.AddWithValue("@name", c.CustomerName);
            com_addCust.Parameters.AddWithValue("@email", c.CustomerEmail);
            com_addCust.Parameters.AddWithValue("@mobile", c.CustomerMobile);
            com_addCust.Parameters.AddWithValue("@gender", c.CustomerGender);
            com_addCust.Parameters.AddWithValue("@password", c.CustomerPassword);
            SqlParameter p_cid = new SqlParameter();
            p_cid.Direction = ParameterDirection.ReturnValue;
            com_addCust.Parameters.Add(p_cid);
            try
            {

                con.Open();
                com_addCust.ExecuteNonQuery();
                con.Close();
                int custID = Convert.ToInt32(p_cid.Value);
                return custID;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public int AddAccounts(Accounts a)
        {
            if (a == null)
            {
                throw new Exception("Invalid Add Account");
            }
            SqlCommand com_addAcc = new SqlCommand("p_addAccount", con);
            com_addAcc.CommandType = CommandType.StoredProcedure;
            com_addAcc.Parameters.AddWithValue("@cid", a.CustomerID);
            com_addAcc.Parameters.AddWithValue("@balance", a.AccountBalance);
            com_addAcc.Parameters.AddWithValue("@type", a.AccountType);
            SqlParameter p_accID = new SqlParameter();
            p_accID.Direction = ParameterDirection.ReturnValue;
            com_addAcc.Parameters.Add(p_accID);
            try
            {
                con.Open();
                com_addAcc.ExecuteNonQuery();
                con.Close();
                int accID = Convert.ToInt32(p_accID.Value);
                return accID;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public int AddTransaction(Transactions t)
        {
            if (t == null)
            {
                throw new Exception("Invalid Add Transaction");
            }
            SqlCommand com_addTran = new SqlCommand("p_addTransaction", con);
            com_addTran.CommandType = CommandType.StoredProcedure;
            com_addTran.Parameters.AddWithValue("@aid", t.AccountID);
            com_addTran.Parameters.AddWithValue("@amount", t.Amount);
            com_addTran.Parameters.AddWithValue("@type", t.TransactionType);
            SqlParameter p_tranID = new SqlParameter();
            p_tranID.Direction = ParameterDirection.ReturnValue;
            com_addTran.Parameters.Add(p_tranID);
            try
            {
                con.Open();
                com_addTran.ExecuteNonQuery();
                con.Close();
                int tranID = Convert.ToInt32(p_tranID.Value);
                return tranID;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool Login(Customers c)
        {
            if (c == null)
            {
                throw new Exception("Invalid Login");
            }
            SqlCommand com_login = new SqlCommand("p_login", con);
            com_login.CommandType = CommandType.StoredProcedure;
            com_login.Parameters.AddWithValue("@id", c.CustomerID);
            com_login.Parameters.AddWithValue("@psw", c.CustomerPassword);
            SqlParameter p_lID = new SqlParameter();
            p_lID.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(p_lID);
            try
            {
                con.Open();
                SqlDataReader dr = com_login.ExecuteReader();
                int pid = Convert.ToInt32(p_lID.Value);
                if (pid == 1)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<ShowTransaction> showTransactions(int id)
        {
            SqlCommand com_tranShow = new SqlCommand("p_ShowTransactions", con);
            com_tranShow.CommandType = CommandType.StoredProcedure;
            com_tranShow.Parameters.AddWithValue("@id", id);
            try
            {
                con.Open();
                SqlDataReader dr = com_tranShow.ExecuteReader();
                List<ShowTransaction> list = new List<ShowTransaction>();
                while (dr.Read())
                {
                    ShowTransaction s = new ShowTransaction();
                    s.TransactionID = dr.GetInt32(0);
                    s.AccountID = dr.GetInt32(1);
                    s.Amount = dr.GetInt32(2);
                    s.TransactionType = dr.GetString(3);
                    s.TransactionDate = dr.GetDateTime(4).ToString();
                    list.Add(s);
                }
                return list;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }           
        }
        public int GetID(int id)
        {
            SqlCommand com_getID = new SqlCommand("p_getAccID", con);
            com_getID.CommandType = CommandType.StoredProcedure;
            com_getID.Parameters.AddWithValue("@id", id);
            try
            {
                con.Open();
                SqlDataReader dr = com_getID.ExecuteReader();
                if (dr.Read())
                {
                    int did = dr.GetInt32(1);
                    if (did == id)
                    {
                        return dr.GetInt32(0);
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public GetCustomer GetCust(int id)
        {
            SqlCommand com_getCust = new SqlCommand("p_GetCustomer", con);
            com_getCust.CommandType = CommandType.StoredProcedure;
            com_getCust.Parameters.AddWithValue("@id", id);
            try
            {
                con.Open();
                SqlDataReader dr = com_getCust.ExecuteReader();
                if (dr.Read())
                {
                    GetCustomer g = new GetCustomer();
                    g.CustomerID = dr.GetInt32(0);
                    g.CustomerName = dr.GetString(1);
                    con.Close();
                    return g;
                }
                else
                {
                    con.Close();
                    return null;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public GetAcc GetAccount(int aid)
        {
            SqlCommand com_getAcc = new SqlCommand("p_GetAcc", con);
            com_getAcc.CommandType = CommandType.StoredProcedure;
            com_getAcc.Parameters.AddWithValue("@id", aid);
            try
            {
                con.Open();
                SqlDataReader dr = com_getAcc.ExecuteReader();
                if (dr.Read())
                {
                    GetAcc a = new GetAcc();
                    a.AccountID = dr.GetInt32(0);
                    a.CustomerID = dr.GetInt32(1);
                    a.AccountBalance = dr.GetInt32(2);
                    a.AccountType = dr.GetString(3);
                    a.AccOpenDate = dr.GetDateTime(4).ToString();
                    con.Close();
                    return a;
                }
                else
                {
                    con.Close();
                    return null;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}
