﻿namespace Win_Banking_Application_ADO
{
    partial class frm_NewAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_newAccount = new System.Windows.Forms.Label();
            this.lbl_accCustID = new System.Windows.Forms.Label();
            this.lbl_accBal = new System.Windows.Forms.Label();
            this.lbl_accType = new System.Windows.Forms.Label();
            this.txt_accCustID = new System.Windows.Forms.TextBox();
            this.txt_accBal = new System.Windows.Forms.TextBox();
            this.cmb_accType = new System.Windows.Forms.ComboBox();
            this.btn_accSubmit = new System.Windows.Forms.Button();
            this.lbl_accStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_newAccount
            // 
            this.lbl_newAccount.AutoSize = true;
            this.lbl_newAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_newAccount.ForeColor = System.Drawing.Color.Purple;
            this.lbl_newAccount.Location = new System.Drawing.Point(322, 56);
            this.lbl_newAccount.Name = "lbl_newAccount";
            this.lbl_newAccount.Size = new System.Drawing.Size(192, 32);
            this.lbl_newAccount.TabIndex = 0;
            this.lbl_newAccount.Text = "New Account";
            // 
            // lbl_accCustID
            // 
            this.lbl_accCustID.AutoSize = true;
            this.lbl_accCustID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accCustID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_accCustID.Location = new System.Drawing.Point(123, 168);
            this.lbl_accCustID.Name = "lbl_accCustID";
            this.lbl_accCustID.Size = new System.Drawing.Size(132, 25);
            this.lbl_accCustID.TabIndex = 1;
            this.lbl_accCustID.Text = "Customer ID :";
            // 
            // lbl_accBal
            // 
            this.lbl_accBal.AutoSize = true;
            this.lbl_accBal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accBal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_accBal.Location = new System.Drawing.Point(123, 249);
            this.lbl_accBal.Name = "lbl_accBal";
            this.lbl_accBal.Size = new System.Drawing.Size(222, 25);
            this.lbl_accBal.TabIndex = 2;
            this.lbl_accBal.Text = "Enter Account Balance :";
            // 
            // lbl_accType
            // 
            this.lbl_accType.AutoSize = true;
            this.lbl_accType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_accType.Location = new System.Drawing.Point(123, 324);
            this.lbl_accType.Name = "lbl_accType";
            this.lbl_accType.Size = new System.Drawing.Size(145, 25);
            this.lbl_accType.TabIndex = 3;
            this.lbl_accType.Text = "Account Type :";
            // 
            // txt_accCustID
            // 
            this.txt_accCustID.Location = new System.Drawing.Point(351, 169);
            this.txt_accCustID.Name = "txt_accCustID";
            this.txt_accCustID.Size = new System.Drawing.Size(253, 26);
            this.txt_accCustID.TabIndex = 4;
            // 
            // txt_accBal
            // 
            this.txt_accBal.Location = new System.Drawing.Point(351, 248);
            this.txt_accBal.Name = "txt_accBal";
            this.txt_accBal.Size = new System.Drawing.Size(253, 26);
            this.txt_accBal.TabIndex = 5;
            // 
            // cmb_accType
            // 
            this.cmb_accType.FormattingEnabled = true;
            this.cmb_accType.Location = new System.Drawing.Point(351, 324);
            this.cmb_accType.Name = "cmb_accType";
            this.cmb_accType.Size = new System.Drawing.Size(253, 28);
            this.cmb_accType.TabIndex = 6;
            // 
            // btn_accSubmit
            // 
            this.btn_accSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_accSubmit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_accSubmit.Location = new System.Drawing.Point(392, 398);
            this.btn_accSubmit.Name = "btn_accSubmit";
            this.btn_accSubmit.Size = new System.Drawing.Size(157, 56);
            this.btn_accSubmit.TabIndex = 7;
            this.btn_accSubmit.Text = "Submit";
            this.btn_accSubmit.UseVisualStyleBackColor = true;
            this.btn_accSubmit.Click += new System.EventHandler(this.btn_accSubmit_Click);
            // 
            // lbl_accStatus
            // 
            this.lbl_accStatus.AutoSize = true;
            this.lbl_accStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accStatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_accStatus.Location = new System.Drawing.Point(375, 507);
            this.lbl_accStatus.Name = "lbl_accStatus";
            this.lbl_accStatus.Size = new System.Drawing.Size(189, 25);
            this.lbl_accStatus.TabIndex = 8;
            this.lbl_accStatus.Text = "New Account Status";
            // 
            // frm_NewAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 718);
            this.Controls.Add(this.lbl_accStatus);
            this.Controls.Add(this.btn_accSubmit);
            this.Controls.Add(this.cmb_accType);
            this.Controls.Add(this.txt_accBal);
            this.Controls.Add(this.txt_accCustID);
            this.Controls.Add(this.lbl_accType);
            this.Controls.Add(this.lbl_accBal);
            this.Controls.Add(this.lbl_accCustID);
            this.Controls.Add(this.lbl_newAccount);
            this.Name = "frm_NewAccount";
            this.Text = "frm_NewAccount";
            this.Load += new System.EventHandler(this.frm_NewAccount_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_newAccount;
        private System.Windows.Forms.Label lbl_accCustID;
        private System.Windows.Forms.Label lbl_accBal;
        private System.Windows.Forms.Label lbl_accType;
        private System.Windows.Forms.TextBox txt_accCustID;
        private System.Windows.Forms.TextBox txt_accBal;
        private System.Windows.Forms.ComboBox cmb_accType;
        private System.Windows.Forms.Button btn_accSubmit;
        private System.Windows.Forms.Label lbl_accStatus;
    }
}