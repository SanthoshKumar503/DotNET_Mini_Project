﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application_ADO
{
    public partial class frm_NewAccount : Form
    {
        public frm_NewAccount()
        {
            InitializeComponent();
        }

        private void btn_accSubmit_Click(object sender, EventArgs e)
        {
            string id = txt_accCustID.Text;
            string bal = txt_accBal.Text;
            string type = cmb_accType.Text;
            bool sts = false;
            int b=0;
            if (bal != string.Empty)
            {
                sts = Validation.IsID(bal);
                b = Convert.ToInt32(bal);
            }
            if(id==string.Empty)
            {
                lbl_accStatus.Text = "Provide Customer ID";
            }
            else if(bal==string.Empty)
            {
                lbl_accStatus.Text = "Enter Balance";
            }
            else if(sts==false)
            {
                lbl_accStatus.Text = "Enter Valid balance";
            }
            else if(b<0)
            {
                lbl_accStatus.Text = "Enter balance above zero";
            }
            else if(type==string.Empty)
            {
                lbl_accStatus.Text = "Select account type";
            }
            else
            {
                try
                {
                    Accounts a = new Accounts();
                    a.CustomerID = Convert.ToInt32(id);
                    a.AccountBalance = b;
                    a.AccountType = type;
                    BankingDAL dal = new BankingDAL();
                    int aid = dal.AddAccounts(a);
                    lbl_accStatus.Text = "Account ID:" + aid;
                    frm_Login l = new frm_Login();
                    l.Show();
                }catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }           
            }

        }

        private void frm_NewAccount_Load(object sender, EventArgs e)
        {
            try
            {
                txt_accCustID.Text = frm_Home.custID.ToString();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            cmb_accType.Items.Add("Saving");
            cmb_accType.Items.Add("Current");
        }
    }
}
