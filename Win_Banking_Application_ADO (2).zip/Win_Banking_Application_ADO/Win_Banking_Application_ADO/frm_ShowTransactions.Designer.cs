﻿namespace Win_Banking_Application_ADO
{
    partial class frm_ShowTransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_showTransaction = new System.Windows.Forms.DataGridView();
            this.lbl_shoeAvilBal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showTransaction)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(342, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "My Transactions";
            // 
            // dgv_showTransaction
            // 
            this.dgv_showTransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_showTransaction.Location = new System.Drawing.Point(81, 151);
            this.dgv_showTransaction.Name = "dgv_showTransaction";
            this.dgv_showTransaction.RowTemplate.Height = 28;
            this.dgv_showTransaction.Size = new System.Drawing.Size(815, 513);
            this.dgv_showTransaction.TabIndex = 1;
            this.dgv_showTransaction.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_showTransaction_CellContentClick);
            // 
            // lbl_shoeAvilBal
            // 
            this.lbl_shoeAvilBal.AutoSize = true;
            this.lbl_shoeAvilBal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_shoeAvilBal.Location = new System.Drawing.Point(117, 104);
            this.lbl_shoeAvilBal.Name = "lbl_shoeAvilBal";
            this.lbl_shoeAvilBal.Size = new System.Drawing.Size(157, 20);
            this.lbl_shoeAvilBal.TabIndex = 2;
            this.lbl_shoeAvilBal.Text = "Available Balance is :";
            // 
            // frm_ShowTransactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 676);
            this.Controls.Add(this.lbl_shoeAvilBal);
            this.Controls.Add(this.dgv_showTransaction);
            this.Controls.Add(this.label1);
            this.Name = "frm_ShowTransactions";
            this.Text = "frm_ShowTransactions";
            this.Load += new System.EventHandler(this.frm_ShowTransactions_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showTransaction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv_showTransaction;
        private System.Windows.Forms.Label lbl_shoeAvilBal;
    }
}