﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application_ADO
{
    public partial class frm_addTransaction : Form
    {
        public frm_addTransaction()
        {
            InitializeComponent();
        }

        private void frm_addTransaction_Load(object sender, EventArgs e)
        {
            try
            {
                txt_tranAccID.Text = frm_Home.accID.ToString();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            cmb_tranType.Items.Add("Debit");
            cmb_tranType.Items.Add("Credit");
        }

        private void btn_tranMakePay_Click(object sender, EventArgs e)
        {
            string aid = txt_tranAccID.Text;
            string amt = txt_tranAmt.Text;
            string type = cmb_tranType.Text;
            int amt2=0;

            bool sts = false;            
            if (aid!=string.Empty)
            {
                sts = Validation.IsID(aid);
            }

            bool sts2 = false;
            if (amt != string.Empty)
            {
                sts2 = Validation.IsID(amt);
            }
            if(sts2==true)
            {
                amt2 = Convert.ToInt32(amt);
            }

            if (aid==string.Empty)
            {
                lbl_tranStatus.Text = "Enter Account ID";
            }
            else if(sts==false)
            {
                lbl_tranStatus.Text = "Enter Valid ID in Int";
            }
            else if(Convert.ToInt32(aid)!=frm_Home.accID)
            {
                lbl_tranStatus.Text = "Invalid ID";
            }
            else if(amt==string.Empty)
            {
                lbl_tranStatus.Text = "Enter Amount";
            }
            else if(sts2==false)
            {
                lbl_tranStatus.Text = "Enter Valid amount";
            }
            else if(amt2==0)
            {
                lbl_tranStatus.Text = "Enter amount above zero";
            }
            else if(amt2<0)
            {
                lbl_tranStatus.Text = "Enter amount above zero";
            }
            else if(type==string.Empty)
            {
                lbl_tranStatus.Text = "Select Transaction Type";
            }
            else
            {
                try
                {
                    GetAcc g = new GetAcc();
                    BankingDAL d = new BankingDAL();
                    g = d.GetAccount(frm_Home.accID);
                    int abal = g.AccountBalance;
                    Accounts a = new Accounts();
                    Transactions t = new Transactions();
                    t.AccountID = Convert.ToInt32(aid);
                    t.Amount = Convert.ToInt32(amt);
                    t.TransactionType = type;
                    if (type == "Debit")
                    {
                        if (abal < t.Amount)
                        {
                            lbl_tranStatus.Text = "Insuficient balance";
                        }
                        else
                        {
                            BankingDAL dal = new BankingDAL();
                            int tid = dal.AddTransaction(t);
                            lbl_tranStatus.Text = "Transaction ID:" + tid;
                        }
                    }
                    else if (type == "Credit")
                    {
                        if (t.Amount == 0 && t.Amount < 1)
                        {
                            lbl_tranStatus.Text = "Enter Balace above zero";
                        }
                        else
                        {
                            BankingDAL dal = new BankingDAL();
                            int tid = dal.AddTransaction(t);
                            lbl_tranStatus.Text = "Transaction ID:" + tid;
                        }
                    }
                    else
                    {
                        lbl_tranStatus.Text = "Invalid Type";
                    }
                }catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
